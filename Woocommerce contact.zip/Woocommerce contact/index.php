<?php
/*
Plugin name: Woocommerce Contact
Description: Extension pour WooCommerce qui vous permet d'activer des boutons de contact sur vos pages produits Les clients peuvent utiliser le bouton Appeler pour vous appeler directement, ils utilisent le bouton WhatsApp pour vous envoyer des messages sur WhatsApp avec les détails du produit, le bouton SMS permet également au client de vous envoyer un message avec les détails du produit. Ces fonctionnalités peuvent vous permettre de faire plus de vente.
Version: 1.1
Author: Aimé SAWADOGO
Author URI: wa.me/+22676717865
Licence: GPLv2 or later
Licence URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

// Assurez-vous de ne pas exposer d'informations si le script est appelé directement
if (!defined('ABSPATH')) {
    exit; // Quittez si accédé directement
}

// Ajoutez le chemin de l'image d'en-tête
define('MON_PLUGIN_IMAGE_HEADER', plugins_url('images/Profil wc.jpg', __FILE__));

// Validation des données d'entrée et protection contre les failles CSRF
function wc_whatsapp_checkout_sanitize_input() {
    if (isset($_POST['wc_whatsapp_checkout_nonce_field']) && wp_verify_nonce($_POST['wc_whatsapp_checkout_nonce_field'], 'wc_whatsapp_checkout_nonce')) {
        $whatsapp_number = sanitize_text_field($_POST['wc_whatsapp_checkout_whatsapp_number']);
        $call_number = sanitize_text_field($_POST['wc_whatsapp_checkout_call_number']);
        $sms_number = sanitize_text_field($_POST['wc_whatsapp_checkout_sms_number']);

        // Traitez les données en toute sécurité
        update_option('wc_whatsapp_checkout_whatsapp_number', $whatsapp_number);
        update_option('wc_whatsapp_checkout_call_number', $call_number);
        update_option('wc_whatsapp_checkout_sms_number', $sms_number);


 // Invalidez le cache après la mise à jour des paramètres
        delete_transient('wc_whatsapp_checkout_cached_data');

        // Ajoutez une notification utilisateur
        add_settings_error('wc_whatsapp_checkout_settings_updated', 'wc_whatsapp_checkout_settings_updated', 'Paramètres mis à jour avec succès', 'updated');


    }
}
add_action('init', 'wc_whatsapp_checkout_sanitize_input');

// Contrôle d'accès basé sur les capacités
function wc_whatsapp_checkout_authorization_check() {
    if (current_user_can('manage_options')) {

      // L'utilisateur a les autorisations nécessaires
    }
}
add_action('init', 'wc_whatsapp_checkout_authorization_check');


// Vérifie si la page actuelle est la page de configuration de votre plugin
function is_wc_whatsapp_checkout_settings_page() {
    // Vérifie le contexte de la page pour déterminer si c'est la page de configuration de votre plugin
    if (isset($_GET['page']) && $_GET['page'] === 'wc-whatsapp-checkout-settings') {
        return true; // Page de configuration de votre plugin
    }
    return false; // Autre page
}

// Fonction pour supprimer les actions d'affichage de messages des autres plugins
function remove_other_plugins_admin_messages() {
    // Vérifie si la page en cours est celle de configuration de votre plugin
    if (is_wc_whatsapp_checkout_settings_page()) {
        // Supprime toutes les actions d'affichage de messages ajoutées par d'autres plugins
        remove_all_actions('admin_notices');
    }
}

// Ajoutez une action pour supprimer les messages d'autres plugins sur la page de configuration de votre plugin
add_action('admin_init', 'remove_other_plugins_admin_messages');


// Ajouter une section pour la désactivation des boutons WhatsApp
function wc_whatsapp_checkout_add_disable_section() {
    add_settings_section('wc_whatsapp_checkout_disable_section', 'Désactiver les boutons de contact', 'wc_whatsapp_checkout_disable_section_callback', 'wc_whatsapp_checkout_settings');
}
add_action('admin_init', 'wc_whatsapp_checkout_add_disable_section');

// Callback pour afficher les options de désactivation des boutons WhatsApp
function wc_whatsapp_checkout_disable_section_callback() {
    echo '<p>Cliquez sur le bouton ci-dessous pour désactiver les boutons de contact sur le site si vous n\'êtes pas disponible pour prendre des appels téléphoniques de vos clients. Il suffit de cocher pour désactiver. Ou décocher pour activer les boutons de contact.</p>';
}

// Enregistrer l'option pour désactiver les boutons WhatsApp
function wc_whatsapp_checkout_register_disable_option() {
    add_settings_field('wc_whatsapp_checkout_disable_buttons', 'Désactiver les boutons de contact', 'wc_whatsapp_checkout_disable_buttons_callback', 'wc_whatsapp_checkout_settings', 'wc_whatsapp_checkout_disable_section');
    register_setting('wc_whatsapp_checkout_settings_group', 'wc_whatsapp_checkout_disable_buttons', 'esc_attr');
}
add_action('admin_init', 'wc_whatsapp_checkout_register_disable_option');

// Callback pour afficher le bouton de désactivation des boutons WhatsApp
function wc_whatsapp_checkout_disable_buttons_callback() {
    $disable_buttons = get_option('wc_whatsapp_checkout_disable_buttons', '0');
    $checked = $disable_buttons == '1' ? 'checked' : '';
    echo "<input type='checkbox' id='wc_whatsapp_checkout_disable_buttons' name='wc_whatsapp_checkout_disable_buttons' value='1' $checked />";
}


// Enregistrez le numéro WhatsApp et les autres numéros de contact
function wc_whatsapp_checkout_register_contact_numbers()
{
    add_settings_section('wc_whatsapp_checkout_contact_section', 'Numéros de contact', 'wc_whatsapp_checkout_contact_section_callback', 'wc_whatsapp_checkout_settings');

    add_settings_field('wc_whatsapp_checkout_whatsapp_number', 'Numéro WhatsApp', 'wc_whatsapp_checkout_whatsapp_number_callback', 'wc_whatsapp_checkout_settings', 'wc_whatsapp_checkout_contact_section');
    register_setting('wc_whatsapp_checkout_settings_group', 'wc_whatsapp_checkout_whatsapp_number', 'esc_attr');

    add_settings_field('wc_whatsapp_checkout_call_number', 'Numéro d\'appel', 'wc_whatsapp_checkout_call_number_callback', 'wc_whatsapp_checkout_settings', 'wc_whatsapp_checkout_contact_section');
    register_setting('wc_whatsapp_checkout_settings_group', 'wc_whatsapp_checkout_call_number', 'esc_attr');

    add_settings_field('wc_whatsapp_checkout_sms_number', 'Numéro SMS', 'wc_whatsapp_checkout_sms_number_callback', 'wc_whatsapp_checkout_settings', 'wc_whatsapp_checkout_contact_section');
    register_setting('wc_whatsapp_checkout_settings_group', 'wc_whatsapp_checkout_sms_number', 'esc_attr');
}
add_action('admin_init', 'wc_whatsapp_checkout_register_contact_numbers');



function wc_whatsapp_checkout_contact_section_callback()
{
    echo '<p>Entrez vos numéros de contact ici (avec les code du pays. Ex: +226)</p>';
}

function wc_whatsapp_checkout_whatsapp_number_callback()
{
    $whatsapp_number = get_option('wc_whatsapp_checkout_whatsapp_number');
    echo "<input type='text' id='wc_whatsapp_checkout_whatsapp_number' name='wc_whatsapp_checkout_whatsapp_number' value='$whatsapp_number' />";
}

function wc_whatsapp_checkout_call_number_callback()
{
    $call_number = get_option('wc_whatsapp_checkout_call_number');
    echo "<input type='text' id='wc_whatsapp_checkout_call_number' name='wc_whatsapp_checkout_call_number' value='$call_number' />";
}

function wc_whatsapp_checkout_sms_number_callback()
{
    $sms_number = get_option('wc_whatsapp_checkout_sms_number');
    echo "<input type='text' id='wc_whatsapp_checkout_sms_number' name='wc_whatsapp_checkout_sms_number' value='$sms_number' />";
}


// Ajouter une section pour sélectionner les pays
function wc_whatsapp_checkout_add_country_section() {
    add_settings_section('wc_whatsapp_checkout_country_section', 'Pays sélectionnés', 'wc_whatsapp_checkout_country_section_callback', 'wc_whatsapp_checkout_settings');
}
add_action('admin_init', 'wc_whatsapp_checkout_add_country_section');

function wc_whatsapp_checkout_country_section_callback() {
    echo '<p>Sélectionnez les pays où vous souhaitez afficher les boutons Appeler et SMS.</p>';
}



// Enregistrer les pays sélectionnés
function wc_whatsapp_checkout_register_selected_countries() {
    add_settings_field('wc_whatsapp_checkout_selected_countries', 'Pays sélectionnés', 'wc_whatsapp_checkout_selected_countries_callback', 'wc_whatsapp_checkout_settings', 'wc_whatsapp_checkout_country_section');
    register_setting('wc_whatsapp_checkout_settings_group', 'wc_whatsapp_checkout_selected_countries', 'wc_whatsapp_checkout_sanitize_selected_countries');
}
add_action('admin_init', 'wc_whatsapp_checkout_register_selected_countries');

// Fonction pour nettoyer et valider les données des pays sélectionnés
function wc_whatsapp_checkout_sanitize_selected_countries($input) {
    // Nettoyer les données et les valider ici si nécessaire
    return $input;
}

// Callback pour afficher les options de sélection des pays
function wc_whatsapp_checkout_selected_countries_callback() {
    $selected_countries = get_option('wc_whatsapp_checkout_selected_countries', array());
    $all_countries = WC()->countries->get_countries();

    echo '<select multiple name="wc_whatsapp_checkout_selected_countries[]">';
    foreach ($all_countries as $code => $country) {
        $selected = in_array($code, (array) $selected_countries) ? 'selected' : '';
        echo "<option value='$code' $selected>$country</option>";
    }
    echo '</select>';
}


function get_admin_country() {
    // Récupérez les options de localisation du site WordPress
    $wp_settings = get_option('general');

   }


// Afficher les boutons fixes sur les pages produits de WooCommerce
function wc_whatsapp_checkout_display_fixed_buttons() {
    global $product;

// Récupérer le pays du visiteur
$visitor_country = WC()->customer->get_country();

// Récupérer le pays choisi
$admin_country = get_admin_country();

// Récupérer l'état de désactivation des boutons
$disable_buttons = get_option('wc_whatsapp_checkout_disable_buttons', '0');

// Si les trois autres boutons sont désactivés ou si le pays choisi ne correspond pas au pays du visiteur, afficher le nouveau bouton WhatsApp
if ($disable_buttons == '1') {
    // Récupérer le numéro WhatsApp et le lien du produit
    $whatsapp_number = ('wc_whatsapp_checkout');
    $product_link = $product ? get_permalink($product->get_id()) : '';

    // Afficher le nouveau bouton WhatsApp
    echo "<button class='whatsapp-button' onclick='sendWhatsAppMessage(\"$whatsapp_number\", \"" . $product->get_name() . "\", \"$product_link\")'><i class='fab fa-whatsapp'></i> WhatsApp</button>";

    // Ajouter du CSS pour le bouton WhatsApp
    echo '<style>
        .whatsapp-button {
            position: fixed;
            bottom: 20px;
            left: 20px;
            z-index: 9999;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            background-color: green;
            color: white;
        }
        .whatsapp-button i {
            margin-right: 5px;
        }
    </style>';

    // Ajouter du JavaScript pour le bouton WhatsApp
    echo '<script>
        function sendWhatsAppMessage(number, productName, productLink) {
            var message = "Je suis intéressé par ce produit: " + productName + ". Voici le lien: " + productLink;
            var whatsappLink = "https://wa.me/" + number + "?text=" + encodeURIComponent(message);
            window.open(whatsappLink, "_blank", "width=600,height=400");
        }
    </script>';
}



if (get_option('wc_whatsapp_checkout_disable_buttons', '0') == '1') {
        return; // Boutons désactivés
    }


 $admin_country = get_admin_country();
    // Récupérer le pays du visiteur
$visitor_country = WC()->customer->get_billing_country();

 // Assurez-vous que $whatsapp_number est défini avant son utilisation
$whatsapp_number = get_option('wc_whatsapp_checkout_whatsapp_number');


// Récupérez le pays de l'administrateur
    $admin_country = get_admin_country();

   // Récupérer le pays du visiteur
$visitor_country = WC()->customer->get_billing_country();

    // Vérifiez si le pays du visiteur correspond au pays de l'administrateur
    if ($visitor_country === $admin_country);

// Numéro WhatsApp
    $whatsapp_number = ('wc__checkout_whatsapp');
    // Numéro d'appel
    $call_number = ('wc__checkout_call');
    // Numéro SMS
    $sms_number = ('wc__checkout_sms');

    // Pays sélectionnés
    $selected_countries = get_option('wc_whatsapp_checkout_selected_countries', array());

    // Lien du produit
    $product_link = get_permalink($product->get_id());

    // Message SMS
    $sms_message = "Je suis intéressé par ce produit: " . $product->get_name() . ". Voici le lien: " . $product_link;

      
    if ( is_array($selected_countries) && in_array(WC()->customer->get_country(), $selected_countries))
{
        // Afficher les boutons fixes
        echo '<div class="fixed-buttons">';
        echo "<button class='call-button' onclick='callVendor(\"$call_number\")'><i class='fas fa-phone'></i> Appeler</button>";
        echo "<button class='whatsapp-button' onclick='sendWhatsAppMessage(\"$whatsapp_number\", \"" . $product->get_name() . "\", \"$product_link\")'><i class='fab fa-whatsapp'></i> WhatsApp</button>";
        echo "<button class='sms-button' onclick='sendSMSMessage(\"$sms_number\", \"$sms_message\")'><i class='fas fa-comment'></i> SMS</button>";
        echo '</div>';

        // JavaScript pour les fonctionnalités des boutons
        echo '<script>
            function callVendor(number) {
                window.location.href = "tel:" + number;
            }        

function sendWhatsAppMessage(number, productName, productLink) {
                var message = "Je suis intéressé  par ce produit: " + productName + ". Voici le lien: " + productLink;
                var whatsappLink = "https://wa.me/" + number + "?text=" + encodeURIComponent(message);
                window.open(whatsappLink, "_blank", "width=600,height=400");
            }


            function sendSMSMessage(number, message) {
                var userAgent = navigator.userAgent || navigator.vendor || window.opera;
                if (/android/i.test(userAgent)) {
                    window.location.href = "sms:" + number + "?body=" + encodeURIComponent(message);
                } else if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
                    window.location.href = "sms:" + number + "&body=" + encodeURIComponent(message);
                } else {
                    window.location.href = "sms:" + number + "?body=" + encodeURIComponent(message);
                }
            }
        </script>';

        // CSS pour les boutons fixes
        echo '<style>
            .fixed-buttons {
                position: fixed;
                bottom: 20px; /* Ajustez cette valeur selon votre mise en page */
                left: 20px; /* Ajustez cette valeur selon votre mise en page */
                z-index: 9999;
                display: flex;
            }

            .fixed-buttons button.call-button {
                margin-right: 10px;
                padding: 10px 15px;
                background-color: red;
                border: none;
                border-radius: 20px;
                color: white;
                font-size: 16px;
                cursor: pointer;
                display: flex;
                align-items: center;
            }

            .fixed-buttons button.whatsapp-button {
                margin-right: 10px;
                padding: 10px 15px;
                background-color: green;
                border: none;
                border-radius: 20px;
                color: white;
                font-size: 16px;
                cursor: pointer;
                display: flex;
                align-items: center;
            }

            .fixed-buttons button.sms-button {
                margin-right: 10px;
                padding: 10px 15px;
                background-color: brown;
                border: none;
                border-radius: 20px;
                color: white;
                font-size: 16px;
                cursor: pointer;
                display: flex;
                align-items: center;
            }

            .fixed-buttons button i {
                margin-right: 5px;
            }

            .fixed-buttons button:hover {
                background-color: #45a049;
            }
        </style>';
}
}
add_action('woocommerce_single_product_summary', 'wc_whatsapp_checkout_display_fixed_buttons', 30);


// Ajouter une page de configuration dans le menu d'administration 
function wc_whatsapp_checkout_add_admin_menu() { 
    add_menu_page( 'Configuration Woocommerce contact', 'Woocommerce contact', 'manage_options', 'wc-whatsapp-checkout-settings', 'wc_whatsapp_checkout_settings_page' ); 
} 
add_action('admin_menu', 'wc_whatsapp_checkout_add_admin_menu');


// Créer la page de configuration
function wc_whatsapp_checkout_settings_page() {
    ?>
    <div class="wrap">
        <h2>Configuration Woocommerce contact</h2>

<img src="<?php echo plugin_dir_url( __FILE__ ) . 'images/images%20boutons.png'; ?>" alt="Présentation des boutons" />

<p>Woocommerce contact à pour but d'ajouter des boutons de contact sur les pages produits de votre boutique Woocommerce.</p>
        <?php if(isset($_GET['settings-updated']) && $_GET['settings-updated']) { ?>
            <div id="message" class="updated notice is-dismissible"><p>Numéros enregistrés avec succès !</p></div>
        <?php } ?>

        <form method="post" action="options.php">
            <?php settings_fields('wc_whatsapp_checkout_settings_group'); ?>
            <?php do_settings_sections('wc_whatsapp_checkout_settings'); ?>


 <?php do_settings_sections('wc_whatsapp_checkout_disable_section'); // Ajout de la section de désactivation ?>


<?php
settings_errors('wc_whatsapp_checkout_settings_updated'); ?>


            <?php submit_button(); ?>
        </form>
    </div>


<div class="premium-section">
    <h3>Obtenez la version Premium dès maintenant !</h3>
    <p>Débloquez toutes les fonctionnalités avancées de WooCommerce Contact avec notre version Premium. </br> L'offre premium est à vie. </br> </br>
Paiement unique.</p>
    <p>Voici ce que vous obtiendrez avec la version Premium :</p>
    <ul>
        <li><h4>Fonctionnalité avancée 1</h4> Enregistrer vos numéros de contact pour recevoir les appels et messages direct de vos clients.
</li>
        <li><h4>Fonctionnalité avancée 2</h4>
Désactiver les boutons de contact lorsque vous n'êtes pas disponible pour prendre des appels ou recevoir des SMS.
</li>
        <li><h4>Fonctionnalité avancée 3</h4>
N'affichez les boutons Appeler et SMS que dans le pays que vous souhaitez.</li>
    </ul>
    <p>Cliquez sur le bouton ci-dessous pour passer à la version Premium :</p>
    <a href="https://aimesawadogo.gumroad.com/l/wcontact" class="button button-primary">Acheter la version Premium</a>
</div>


    <?php 
}


    
// Inclure les fichiers de WooCommerce
require_once ABSPATH . 'wp-admin/includes/plugin.php';
require_once ABSPATH . 'wp-includes/pluggable.php';
require_once ABSPATH . 'wp-content/plugins/woocommerce/woocommerce.php';


$username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING);
if (!$username) {
    // Gérer l'absence de données ou les données non valides
}


// Vérifier si WooCommerce est activé
if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    // WooCommerce est activé, incluez la classe principale de WooCommerce
    if (!class_exists('WooCommerce')) {
        include_once ABSPATH . 'wp-content/plugins/woocommerce/includes/class-woocommerce.php';
    }
} else {
    // WooCommerce n'est pas activé, gestion de l'erreur ou autre action
}




